<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PagesController extends Controller
{
    /**
    * Create a new controller instance.
    *
    * @return void
    */
    /*
    public function __construct()
    {
        #exceptions
        $this->middleware('auth')->except(['index','shopGrid', 'accountProfile','checkoutShipping',
        'checkoutShipping','checkoutReview','checkoutComplete','accountOrders','shopList']);
    }
    */
    
    public function allCategories(){
        return view('pages.shop-categories');
    }

    public function index(){
        return view ('welcome');
    }

    public function login(){
        return view ('pages.account-login');
    }

    public function accountProfile(){
        return view ('pages.account-profile');
    }

    public function shopGrid(){
        return view ('pages.shop-grid');
    }

    public function shopList(){
        return view ('pages.shop-list');
    }

    public function cart(){
        return view ('pages.cart');
    }

    public function checkoutAddress(){
        return view ('pages.checkout-address');
    }

    public function checkoutComplete(){
        return view('pages.checkout-complete');
    }

    public function checkoutShipping(){
        return view ('pages.checkout-shipping');
    }

    public function checkoutPayment(){
        return view ('pages.checkout-payment');
    }

    public function checkoutReview(){
        return view ('pages.checkout-review');
    }

    public function accountOrders(){
        return view ('pages.account-orders');
    }

    public function faq(){
        return view ('pages.faq');
    }

    
}
