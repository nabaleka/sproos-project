<nav class="list-group">
    <a class="list-group-item justify-content-between" href="/account-orders"><span><i class="icon-bag"></i>Orders</span><span class="badge badge-primary badge-pill">6</span></a>
    <a class="list-group-item active" href="account-profile"><i class="icon-head"></i>Profile</a><a class="list-group-item" href="/account-address"><i class="icon-map"></i>Addresses</a>
    <a class="list-group-item justify-content-between" href="#"><span><i class="icon-heart"></i>Favourites</span><span class="badge badge-primary badge-pill">3</span></a>
    <a class="list-group-item justify-content-between" href="#"><span><i class="icon-tag"></i>My Shop</span><span class="badge badge-primary badge-pill">4</span></a>  
</nav>