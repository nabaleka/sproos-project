<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/** Front End **/
#auth routes
Auth::routes();


#routes to the consumer front end
Route::get('/', 'PagesController@index');

#account routes
Route::get('/create', 'PagesController@login');
Route::get('/account-profile', 'PagesController@accountProfile');
Route::get('/account-orders','PagesController@accountOrders');
Route::get('/faq','PagesController@faq');
Route::get('/home', 'HomeController@index')->name('home');

#shop routes
Route::get('/shop-list','PagesController@shopList');
Route::get('/shop-grid','PagesController@shopGrid');
Route::get('/cart','PagesController@cart');
Route::get('/categories', 'PagesController@allCategories');

#checkout routes
Route::get('/checkout-address','PagesController@checkoutAddress');
Route::get('/checkout-shipping','PagesController@checkoutShipping');
Route::get('/checkout-payment','PagesController@checkoutPayment');
Route::get('/checkout-review','PagesController@checkoutReview');
Route::get('/checkout-complete','PagesController@checkoutComplete');


/** Back end **/
#Routes to the admin controller and views
Route::get('/admin', 'AdminController@index');
Route::get('/admin/blank', 'AdminController@blank');